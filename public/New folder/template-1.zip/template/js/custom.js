
$(document).ready(function(){
	$('.autoplay').slick({
		  slidesToShow: 1,
		  slidesToScroll: 1,
		  autoplay: true,
		  autoplaySpeed: 500,
		  prevArrow: false,
    	  nextArrow: false,
    	  vertical: true
    	  
	});
});